<template>
  <v-layout>
    <v-row>
      <v-col sm="2">
        <v-card v-for="item in items" :key="item.id" class="card-category">
          <v-card-text v-if="item" @click="showItem(item)">
            {{ item.name }}
          </v-card-text>
        </v-card>
      </v-col>
      <v-col> 
          <item :item="current"/>
      </v-col>
    </v-row>
  </v-layout>
</template>

<script>
import api from "~/api/index";
import item from '~/components/item'
export default {
  props: {},
  data() {
    return {
        current: {},
    };
  },
  components: {item},
  asyncData({ params }) {
    console.log("params :", params);
    return api.items.getItemsByCatName(params.name).then(res => {
      return { items: res.data };
    });
  },
  methods: {
    showItem(item) {
      console.log("item :", item);
      this.current = item
    }
  }
};
</script>
<style scoped>
.list {
  float: right;
  background-color: aqua;
  width: 200px;
}
.item {
  float: left;
  background-color: darkgoldenrod;
  width: 100%;
}
.card-category {
  margin: 4px;
}
</style>
