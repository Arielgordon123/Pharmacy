<template>
  <v-card v-if="item != {}">
   <h2> {{ item.name }}</h2>
     
   
    <h4>סמכות:</h4>
    {{ item.authority }}
    <h4>שם בפת״ר:</h4>
    {{ item.patarName }}
    <h4>שם בסאפ:</h4>
    {{ item.sapName }}
    <h4>התוויות נגד:</h4>
    {{ item.neged }}
    <h4>מק״ט:</h4>
    {{ item.serial }}
  </v-card>
</template>

<script>
export default {
  props: {
    item: {
      type: Object,
      default: () => {
        return {
         
        };
      }
    }
  },
  data() {
    return {};
  }
};
</script>

<style></style>
